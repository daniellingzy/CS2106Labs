#!/bin/bash

####################
# Lab 1 Exercise 6
# Name: Daniel Ling Zhi Yuan | Pang Bao Bin
# Student No: A0239285U | A0233347H
# Lab Group: B13 | B02
####################

echo "Printing system call report"

# Compile file
gcc -std=c99 pid_checker.c -o ex6

# Use strace to get report
strace -c ./ex6
