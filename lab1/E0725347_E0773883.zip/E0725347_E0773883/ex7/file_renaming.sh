#!/bin/bash

####################
# Lab 1 Exercise 7
# Name: Daniel Ling Zhi Yuan | Pang Bao Bin
# Student No: A0239285U | A0233347H
# Lab Group: B13 | B02
####################

####################
# Strings that you may need for prompt (not in order)
####################
# Enter $N numbers:
# Enter NEW prefix (only alphabets):
# Enter prefix (only alphabets):
# INVALID
# Number of files to create:
# Please enter a valid number [0-9]:
# Please enter a valid prefix [a-z A-Z]:

####################
# Strings that you may need for prompt (not in order)
####################

#################### Steps #################### 

# Fill in the code to request user for the prefix

# Check the validity of the prefix #

# Enter numbers and create files #

# Fill in the code to request user for the new prefix

# Renaming to new prefix #


echo "Enter prefix (only alphabets):"
read prefix
if [[ $prefix =~  [^[:alpha:]] ]]; 
then 
    echo "INVALID"
    echo "Please enter a valid prefix [a-z A-Z]:"
    read prefix
fi 

echo "Number of files to create:"
read N 

echo "Enter $N numbers:"
for (( i=1; i<=$N; i++ )); do
    read num
    if [[ $num =~  [[:alpha:]] ]]; 
    then 
        echo "INVALID"
        echo "Please enter a valid number [0-9]:"
        read num
    fi 
     touch "${prefix}_${num}".txt 
done

echo "Files Created"
ls *.txt

echo "Enter NEW prefix (only alphabets):"
read newPrefix
for file in $prefix*; do 
    mv "$file" "${file/${prefix}/${newPrefix}}"
done

echo "Files Renamed"
ls *.txt