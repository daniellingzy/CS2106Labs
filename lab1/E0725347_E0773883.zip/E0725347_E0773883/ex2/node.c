/*************************************
* Lab 1 Exercise 2
* Name: Daniel Ling Zhi Yuan | Pang Bao Bin
* Student No: A0239285U | A0233347H
* Lab Group: B13 | B02
*************************************/

#include "node.h"
#include "stdlib.h"

// Add in your implementation below to the respective functions
// Feel free to add any headers you deem fit 


// Inserts a new node with data value at index (counting from head
// starting at 0).
// Note: index is guaranteed to be valid.
void insert_node_at(list *lst, int index, int data) {
    node *cur = lst->head;
    // create new node
    node *new = (node*) malloc(sizeof(node));
    new->data = data;
    new->next = NULL;
    // Empty list
    if (cur == NULL) {
        new->next = NULL;
        lst->head = new;
    } else {
        if (index == 0) {
            new->next = cur;
            lst->head = new;
        } else {
            int i = index-1;
            while (i != 0) {
                cur = cur->next;
                i--;
            }
            if (cur->next == NULL) {
                // Adding to end of list
                cur->next = new;
            } else {
                new->next = cur->next;
                cur->next = new;
            }
        }
    }
}

// Deletes node at index (counting from head starting from 0).
// Note: index is guarenteed to be valid.
void delete_node_at(list *lst, int index) {
    if (index == 0) {
        // delete first node
        node *del = lst->head;
        lst->head = lst->head->next;
        free(del);
    } else {
        int i = index - 1;
        node *cur = lst->head;
        while (i != 0) {
            // traverse to node left of index
            cur = cur->next;
            i--;
        }
        if (cur->next != NULL) {
            // smth to delete at index
            node *del = cur->next;
            cur->next = cur->next->next;
            free(del);
        }
    }
}

// Search list by the given element.
// If element not present, return -1 else return the index. If lst is empty return -2.
//Printing of the index is already handled in ex2.c
int search_list(list *lst, int element) {
    if (lst->head == NULL) {
        // lst is empty
        return -2;
    }
    node *cur = lst->head;
    int index = 0;
    while (cur != NULL) {
        if (cur->data == element) {
            return index;
        } else {
            cur = cur->next;
            index++;
        }
    }
    return -1;
}

// Reverses the list with the last node becoming the first node.
void reverse_list(list *lst) {
    node* cur = lst->head;
    node *prev = NULL, *next = NULL;
 
        while (cur != NULL) {
            // Save next
            next = cur->next;
            // Change cur ptr
            cur->next = prev;
            // Shift ptrs
            prev = cur;
            cur = next;
        }
        lst->head = prev;
}

// Resets list to an empty state (no nodes) and frees
// any allocated memory in the process
void reset_list(list *lst) {
    node *cur = lst->head;
    while (cur != NULL) {
        node *tmp = cur;
        cur = cur->next;
        free(tmp);
        tmp = NULL;
    }
    lst->head = NULL;

}
